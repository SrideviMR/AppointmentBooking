"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const types_1 = require("../../types");
const dynamodb_1 = require("../../utils/dynamodb");
const response_1 = require("../../utils/response");
const time_1 = require("../../utils/time");
async function handler(event) {
    try {
        const bookingId = event.pathParameters?.bookingId;
        if (!bookingId) {
            return (0, response_1.validationError)("bookingId is required");
        }
        const bookingKeys = types_1.Keys.booking(bookingId);
        // Get booking details
        const booking = await (0, dynamodb_1.getItem)(bookingKeys);
        if (!booking) {
            return (0, response_1.notFoundError)("Booking");
        }
        try {
            // Update booking state with condition
            await (0, dynamodb_1.updateItem)(bookingKeys, "SET #state = :cancelled, cancelledAt = :cancelledAt, GSI3PK = :gsi3pk", {
                ":cancelled": "CANCELLED",
                ":cancelledAt": (0, time_1.getCurrentTimestamp)(),
                ":pending": "PENDING",
                ":confirmed": "CONFIRMED",
                ":gsi3pk": "STATUS#CANCELLED",
            }, {
                "#state": "state",
            }, "#state IN (:pending, :confirmed)");
            // Release the slot
            const [date, time] = booking.slotId.split("#");
            const slotKeys = types_1.Keys.slot(booking.providerId, date, time);
            await (0, dynamodb_1.updateItem)(slotKeys, "SET #status = :available REMOVE reservedBy, reservedAt", {
                ":available": "AVAILABLE",
                ":bookingId": bookingId,
            }, {
                "#status": "status",
            }, "reservedBy = :bookingId");
            return (0, response_1.successResponse)({
                bookingId,
                state: "CANCELLED",
                cancelledAt: (0, time_1.getCurrentTimestamp)(),
                message: "Booking cancelled and slot released",
            });
        }
        catch (error) {
            if (error.name === "ConditionalCheckFailedException") {
                return (0, response_1.conflictError)(`Booking cannot be cancelled. Current state: ${booking.state}`);
            }
            throw error;
        }
    }
    catch (error) {
        console.error("Error cancelling booking:", error);
        return (0, response_1.internalError)(error.message);
    }
}
//# sourceMappingURL=cancel-booking.js.map