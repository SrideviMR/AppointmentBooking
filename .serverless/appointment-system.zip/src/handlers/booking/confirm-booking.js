"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const types_1 = require("../../types");
const dynamodb_1 = require("../../utils/dynamodb");
const response_1 = require("../../utils/response");
const time_1 = require("../../utils/time");
async function handler(event) {
    try {
        const bookingId = event.pathParameters?.bookingId;
        if (!bookingId) {
            return (0, response_1.validationError)("bookingId is required");
        }
        const bookingKeys = types_1.Keys.booking(bookingId);
        // Check if booking exists
        const existingBooking = await (0, dynamodb_1.getItem)(bookingKeys);
        if (!existingBooking) {
            return (0, response_1.notFoundError)("Booking");
        }
        try {
            // Update booking state with condition
            const result = await (0, dynamodb_1.updateItem)(bookingKeys, "SET #state = :confirmed, confirmedAt = :confirmedAt, GSI3PK = :gsi3pk", {
                ":confirmed": "CONFIRMED",
                ":confirmedAt": (0, time_1.getCurrentTimestamp)(),
                ":pending": "PENDING",
                ":gsi3pk": "STATUS#CONFIRMED",
            }, {
                "#state": "state",
            }, "#state = :pending");
            return (0, response_1.successResponse)({
                bookingId,
                state: "CONFIRMED",
                confirmedAt: result.Attributes?.confirmedAt,
            });
        }
        catch (error) {
            if (error.name === "ConditionalCheckFailedException") {
                return (0, response_1.conflictError)(`Booking cannot be confirmed. Current state: ${existingBooking.state}`);
            }
            throw error;
        }
    }
    catch (error) {
        console.error("Error confirming booking:", error);
        return (0, response_1.internalError)(error.message);
    }
}
//# sourceMappingURL=confirm-booking.js.map