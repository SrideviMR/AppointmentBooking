"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const types_1 = require("../../types");
const dynamodb_1 = require("../../utils/dynamodb");
const response_1 = require("../../utils/response");
const time_1 = require("../../utils/time");
async function handler(event) {
    try {
        if (!event.body) {
            return (0, response_1.validationError)("Request body is required");
        }
        const input = JSON.parse(event.body);
        // Validation
        if (!input.providerId || !input.name || !input.type) {
            return (0, response_1.validationError)("providerId, name, and type are required");
        }
        if (!["DOCTOR", "SALON", "SERVICE"].includes(input.type)) {
            return (0, response_1.validationError)("type must be DOCTOR, SALON, or SERVICE");
        }
        // Create provider item
        const keys = types_1.Keys.provider(input.providerId);
        const provider = {
            ...keys,
            name: input.name,
            type: input.type,
            createdAt: (0, time_1.getCurrentTimestamp)(),
        };
        await (0, dynamodb_1.putItem)(provider);
        return (0, response_1.successResponse)({
            providerId: input.providerId,
            name: input.name,
            type: input.type,
            createdAt: provider.createdAt,
        }, 201);
    }
    catch (error) {
        console.error("Error creating provider:", error);
        if (error.name === "ConditionalCheckFailedException") {
            return (0, response_1.errorResponse)("Provider already exists", 409);
        }
        return (0, response_1.internalError)(error.message);
    }
}
//# sourceMappingURL=create-provider.js.map