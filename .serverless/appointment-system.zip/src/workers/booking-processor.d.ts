import { SQSEvent } from "aws-lambda";
export declare function handler(event: SQSEvent): Promise<void>;
//# sourceMappingURL=booking-processor.d.ts.map