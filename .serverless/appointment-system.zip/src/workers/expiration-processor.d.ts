import { ScheduledEvent } from "aws-lambda";
export declare function handler(event: ScheduledEvent): Promise<void>;
//# sourceMappingURL=expiration-processor.d.ts.map